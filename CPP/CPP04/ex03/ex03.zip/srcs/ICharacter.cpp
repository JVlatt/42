#include "ICharacter.hpp"

ICharacter::~ICharacter()
{

}
