#include "IMateriaSource.hpp"

IMateriaSource::~IMateriaSource()
{

}
